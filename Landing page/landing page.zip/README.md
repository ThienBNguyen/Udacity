Landing Page Project
Table of Contents
Instructions
Instructions
the project template is from refresh 2019 in github. it already has custom html and css. the project has 4 sections and dynamic navigation bar at the top. when the user scroll down the navigation will disappear if scroll back up it will reappear. the project also built for mobile friendly users.
